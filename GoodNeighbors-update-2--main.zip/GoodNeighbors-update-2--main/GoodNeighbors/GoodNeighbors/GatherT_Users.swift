//
//  GatherT_Users.swift
//  GoodNeighbors
//
//  Created by Christopher Park on 4/14/24.
//

import SwiftUI
class GatherViewHolder {
    static let shared2 = GatherViewHolder()
    var t_uid1 = ""
    var t_uid2 = ""
    var t_uid3 = ""
    var t_uid4 = ""
    var t_uid5 = ""
    
}

struct GatherView: View {
    @EnvironmentObject var sessionManager: SessionManager
    @State private var user1 = ""
    @State private var user2 = ""
    @State private var user3 = ""
    @State private var user4 = ""
    @State private var user5 = ""
    
    var body: some View {
        VStack {
            Text("Please input five users you trust")
            
            TextField("User 1", text: $user1)
            TextField("User 2", text: $user2)
            TextField("User 3", text: $user3)
            TextField("User 4", text: $user4)
            TextField("User 5", text: $user5)
            Button("Login") {
                GatherButtonAction()
            }
        }
    }
    func GatherButtonAction() {
        GatherViewHolder.shared2.t_uid1 = user1
        GatherViewHolder.shared2.t_uid2 = user2
        GatherViewHolder.shared2.t_uid3 = user3
        GatherViewHolder.shared2.t_uid4 = user4
        GatherViewHolder.shared2.t_uid5 = user1
        
    }
    
    func loginUser(user1: String, user2: String, user3: String, user4: String, user5: String) {
        // Here you can perform any actions you want with the user inputs
        // For example, you can save them in variables, send them to a server, etc.
        // For simplicity, I'll just print them here
        print("User 1: \(user1)")
        print("User 2: \(user2)")
        print("User 3: \(user3)")
        print("User 4: \(user4)")
        print("User 5: \(user5)")
    }
}




struct GatherView_Previews: PreviewProvider {
    static var previews: some View {
        GatherView()
    }
}

