//
//  SessionView.swift
//  Authenticated
//
//  Created by Jaewoo Seo on 3/29/24.
//
import Amplify
import SwiftUI
import Foundation
import PolarBleSdk
import AWSS3


struct SessionView: View {
    @EnvironmentObject var sessionManager: SessionManager
    @State var H10INFO = ""
    
    @EnvironmentObject private var bleSdkManager: PolarBleSdkManager
    @State private var selectedTab: SelectedAction = .online
    @State private var isSearchingDevices = false
    @State private var showSettingView = false
    
    let user: AuthUser
    var body: some View {
        NavigationView {
            VStack{
                
                
                Button(action: {
                    self.showSettingView.toggle()
                }) {
                    Text("Go to Second View")
                        .font(.title)
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
                
                NavigationLink(
                    destination: SettingView(),
                    isActive: $showSettingView
                ) {
                    EmptyView()
                }
                .hidden()
                
                if !bleSdkManager.isBluetoothOn {
                    Text("Please turn on Bluetooth")
                        .bold()
                }
                
                
                //Text("You signed in as \(user.username) using Amplify")
                welcomeText(user: user)
                Button("Sign Out", action: sessionManager.signOut)
                
                lastDay()
                
                Text("Today")
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .padding(.trailing, 320)
                fitnessInfo(fitData: fitnessData)
                    .tag(0).overlay(addWidgets())
                Button(action: {
                    uploadData()
                }) {
                    Text("Upload CSVFILE")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                Spacer()
                tabBar()
            }
        }
    }
        
    func uploadData (){
        guard let csvURL = Bundle.main.url(forResource: user.username, withExtension: "csv") else {
            print("CSV file not found!")
            return
        }
        print("clicked")
        // Specify the key for the file (e.g., "example.csv")
        let key = "\(user.username).csv"

        // Upload the file to Amplify Storage
        Amplify.Storage.uploadFile(key: key, local: csvURL) { result in
            switch result {
            case .success:
                print("File uploaded successfully.")
            case .failure(let error):
                print("Failed to upload file:", error)
            }
        }
        
    }
    
    struct welcomeText : View {
        let user: AuthUser
        var body: some View {
            VStack(alignment: .leading) {
                Text("Hello")
                    .font(.system(size: 42, weight: .bold, design: .rounded))
                Text("\(user.username).")
                    .font(.system(size: 40, weight: .bold, design: .rounded))
            }
            .padding(.top, 25)
            .padding(.trailing, 200)
        }
    }

    struct lastDay : View {
        var body: some View {
            HStack(spacing: 5) {
                Image(systemName: "info.circle")
                    .resizable()
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .frame(width: 20, height: 20, alignment: .leading)
                    .foregroundColor(.black)
                    .padding()
                
                Text("You haven't recorded a workout for five days.")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundColor(.black)
                    .layoutPriority(1)
                    .lineLimit(1)
                    .padding()
            }
            .background(Color.gray.opacity(0.2))
            .clipShape(Rectangle())
            .cornerRadius(20)
            .padding()
        }
    }


    struct fitnessInfo: View {
        
        var fitData : [Fitness]
        var columns = Array(repeating: GridItem(.flexible(), spacing: 5), count: 2)
        
        var body: some View {
            LazyVGrid(columns: columns, spacing: 30) {
                ForEach(fitData) {fitness in
                    ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
                        VStack(alignment: .leading, spacing: 25) {
                            Text(fitness.title)
                                .foregroundColor(.white)
                            Text(fitness.data)
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.top, 10)
                            Text(fitness.suggest)
                                .foregroundColor(.white)
                        }
                        .padding()
                        .background(Color(fitness.image))
                        .cornerRadius(10)
                        .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 5)
                    }
                }
            }
            .frame(width: 350, height: 350)
            .padding(.horizontal, 10)
            .padding(.top, 45)
        }
    }

    struct Fitness : Identifiable {
        var id: Int
        var title: String
        var image: String
        var data: String
        var suggest: String
    }

    var fitnessData = [

        Fitness(id: 0, title: "Heart Rate", image: "heart", data: "110 bpm", suggest: "70-130\nHeathly"),
        Fitness(id: 1, title: "Running", image: "running", data: "4.5 km", suggest: "Daily Goal\n10 km"),
        Fitness(id: 2, title: "Cycling", image: "cycle", data: "17.2 km", suggest: "Daily Goal\n20 km"),

    ]

    struct addWidgets : View {
        var body: some View {
            HStack(spacing: 5) {
                Text("+ Add Widgets")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundColor(.black)
                    .layoutPriority(1)
                    .lineLimit(2)
                    .padding()
            }
            .background(Color.gray.opacity(0.2))
            .clipShape(Rectangle())
            .cornerRadius(10)
            .padding()
            .padding(.leading, 170)
            .padding(.top, 130)
        }
    }

    struct tabBar : View {
        var body: some View {
            HStack(spacing: 10) {
                Image(systemName: "house.fill")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(Color("running"))
                    .padding(20)
                
                Image(systemName: "map.fill")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(Color.white)
                    .padding(20)
                
                Image(systemName: "plus")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(Color.white)
                    .padding(20)
                
                Image(systemName: "headphones")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(Color.white)
                    .padding(20)
                
                Image(systemName: "person.fill")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .foregroundColor(Color.white)
                    .padding(20)
            }
            .background(Color.black.opacity(0.6))
            .clipShape(Rectangle())
            .cornerRadius(25)
            .padding()
        }
    }
}
struct SessionView_Previews: PreviewProvider {
    private struct DummyUser: AuthUser {
        let userId: String = "1"
        let username: String = "dummy"
    }
    
    static var previews: some View{
        SessionView(user: DummyUser())
    }
    
}


struct welcomeText : View {
    let user:AuthUser
    var body: some View {
        VStack(alignment: .leading) {
            Text("Hello")
                .font(.system(size: 42, weight: .bold, design: .rounded))
            Text("\(user.username).")
                .font(.system(size: 40, weight: .bold, design: .rounded))
        }
        .padding(.top, 25)
        .padding(.trailing, 200)
    }
}

struct lastDay : View {
    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: "info.circle")
                .resizable()
                .font(.system(size: 20, weight: .bold, design: .rounded))
                .frame(width: 20, height: 20, alignment: .leading)
                .foregroundColor(.black)
                .padding()
            
            Text("You haven't recorded a workout for five days.")
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundColor(.black)
                .layoutPriority(1)
                .lineLimit(1)
                .padding()
        }
        .background(Color.gray.opacity(0.2))
        .clipShape(Rectangle())
        .cornerRadius(20)
        .padding()
    }
}


struct fitnessInfo: View {
    
    var fitData : [Fitness]
    var columns = Array(repeating: GridItem(.flexible(), spacing: 5), count: 2)
    
    var body: some View {
        LazyVGrid(columns: columns, spacing: 30) {
            ForEach(fitData) {fitness in
                ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
                    VStack(alignment: .leading, spacing: 25) {
                        Text(fitness.title)
                            .foregroundColor(.white)
                        Text(fitness.data)
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding(.top, 10)
                        Text(fitness.suggest)
                            .foregroundColor(.white)
                    }
                    .padding()
                    .background(Color(fitness.image))
                    .cornerRadius(10)
                    .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 5)
                }
            }
        }
        .frame(width: 350, height: 350)
        .padding(.horizontal, 10)
        .padding(.top, 45)
    }
}


struct Fitness : Identifiable {
    var id: Int
    var title: String
    var image: String
    var data: String
    var suggest: String
}

var fitnessData = [

    Fitness(id: 0, title: "Heart Rate", image: "heart", data: "110 bpm", suggest: "70-130\nHeathly"),
    Fitness(id: 1, title: "Running", image: "running", data: "4.5 km", suggest: "Daily Goal\n10 km"),
    Fitness(id: 2, title: "Cycling", image: "cycle", data: "17.2 km", suggest: "Daily Goal\n20 km"),

]

struct addWidgets : View {
    var body: some View {
        HStack(spacing: 5) {
            Text("+ Add Widgets")
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundColor(.black)
                .layoutPriority(1)
                .lineLimit(2)
                .padding()
        }
        .background(Color.gray.opacity(0.2))
        .clipShape(Rectangle())
        .cornerRadius(10)
        .padding()
        .padding(.leading, 170)
        .padding(.top, 130)
    }
}

struct tabBar : View {
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "house.fill")
                .resizable()
                .frame(width: 20, height: 20)
                .foregroundColor(Color("running"))
                .padding(20)
            
            Image(systemName: "map.fill")
                .resizable()
                .frame(width: 20, height: 20)
                .foregroundColor(Color.white)
                .padding(20)
            
            Image(systemName: "plus")
                .resizable()
                .frame(width: 20, height: 20)
                .foregroundColor(Color.white)
                .padding(20)
            
            Image(systemName: "headphones")
                .resizable()
                .frame(width: 20, height: 20)
                .foregroundColor(Color.white)
                .padding(20)
            
            Image(systemName: "person.fill")
                .resizable()
                .frame(width: 20, height: 20)
                .foregroundColor(Color.white)
                .padding(20)
        }
        .background(Color.black.opacity(0.6))
        .clipShape(Rectangle())
        .cornerRadius(25)
        .padding()
    }
}
