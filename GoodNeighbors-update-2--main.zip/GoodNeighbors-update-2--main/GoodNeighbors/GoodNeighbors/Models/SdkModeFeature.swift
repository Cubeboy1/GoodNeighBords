/// Copyright © 2023 Polar Electro Oy. All rights reserved.

import Foundation

struct SdkModeFeature {
    var isSupported = false
    var isEnabled = false
}
