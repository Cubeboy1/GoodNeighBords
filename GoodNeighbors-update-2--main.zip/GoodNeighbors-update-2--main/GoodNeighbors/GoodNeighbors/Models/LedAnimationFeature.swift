/// Copyright © 2023 Polar Electro Oy. All rights reserved.
///
import Foundation
import PolarBleSdk

struct LedAnimationFeature {
    var isSupported = false
}
